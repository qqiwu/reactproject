// src/views/kind/Index.tsx
import React, { FC } from 'react';

interface IKindProps {
  
};

const Kind:FC<IKindProps> = () => {
  return (
    <>
      <header className="header">kind header</header>
      <div className="content">kind content</div>
    </>
  )
};

export default Kind;